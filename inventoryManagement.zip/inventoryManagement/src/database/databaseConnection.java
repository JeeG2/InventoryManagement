package database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class databaseConnection {
	
	public static Connection myConnection() throws SQLException{

			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","root");
			//System.out.print("Connected");
		return connection;
	}
}
