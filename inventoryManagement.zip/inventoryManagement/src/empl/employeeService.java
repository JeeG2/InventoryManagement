package empl;

import java.sql.SQLException;

public interface employeeService {

	public boolean login(employee e) throws SQLException;
	public boolean employeeExists(employee e) throws SQLException;
	public boolean changePassword(employee e) throws SQLException;
	public employee fetchOneConfidentialDetail(employee e) throws SQLException;
	
	
}
