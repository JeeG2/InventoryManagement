package main;

import java.util.Scanner;

import RawMaterialOrderdao.RawMaterialOrderdao;
import empl.clearconsole;

public class RawMatrialOrderMainImp {

	public void function() {
		clearconsole.clearConsole();
		System.out.println(" choose \n 1- Place Raw Material Order. \n 2-Display Raw Material Order. \n 3- Update Raw Material Order. \n 4- Track Raw Material Order. \n 5- Update Raw Material Stock. \n 6- Display Supplier Details \n");
		RawMaterialOrderdao rawImplement = new RawMaterialOrderdao();
		Scanner scan = new Scanner(System.in);
		int choice = scan.nextInt();
	}
}
